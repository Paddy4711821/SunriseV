
document.getElementById('whitelistForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const data = new FormData(e.target);
    const msg = {
        content: `Neue Whitelist Bewerbung:\nIC-Name: ${data.get('icname')}\nAlter: ${data.get('age')}\nErfahrung: ${data.get('experience')}\nBegründung: ${data.get('reason')}`
    };
    fetch("DEIN_DISCORD_WEBHOOK_URL", {
        method: "POST",
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(msg)
    }).then(() => alert("Gesendet!"));
});
