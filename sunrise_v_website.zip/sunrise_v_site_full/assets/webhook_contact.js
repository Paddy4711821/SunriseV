
document.getElementById('contactForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const data = new FormData(e.target);
    const msg = {
        content: `Neue Nachricht:\nVon: ${data.get('name')}\nInhalt: ${data.get('message')}`
    };
    fetch("DEIN_DISCORD_WEBHOOK_URL", {
        method: "POST",
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(msg)
    }).then(() => alert("Nachricht gesendet!"));
});
